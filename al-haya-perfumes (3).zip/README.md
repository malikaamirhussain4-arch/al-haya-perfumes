# AL HAYA ATTAR & PERFUMES - E-Commerce Store

Beautiful, free e-commerce website for your perfume and attar business with WhatsApp integration.

## Features
✅ Product showcase with customizable pricing
✅ Shopping cart functionality
✅ WhatsApp order integration
✅ Beautiful purple/rose theme
✅ Mobile responsive design
✅ Completely FREE

## Deploy to Vercel (FREE) - 3 Easy Steps

### Step 1: Prepare Files
1. Download all these files to a folder on your computer
2. Folder structure should be:
```
al-haya-perfumes/
├── index.html
├── main.jsx
├── App.jsx
├── package.json
├── vite.config.js
└── .gitignore
```

### Step 2: Create GitHub Repository
1. Go to github.com and sign in
2. Click "New repository"
3. Name it: `al-haya-perfumes`
4. Check "Add a README file"
5. Click "Create repository"
6. Upload all your files to this repository

### Step 3: Deploy to Vercel
1. Go to vercel.com
2. Click "New Project"
3. Click "Import Git Repository"
4. Select your `al-haya-perfumes` repository
5. Click "Import"
6. Click "Deploy"
7. Wait 1-2 minutes...
8. Your site is LIVE! 🎉

## Your Live URL
After deployment, Vercel will give you a URL like:
`https://al-haya-perfumes.vercel.app`

Share this link with customers!

## How to Add More Products
Edit `App.jsx` and add to the products array:
```javascript
{
  id: 5,
  name: 'Product Name',
  price: { min: 500, max: 1500 },
  type: 'Attar/Perfume',
  description: 'Description here',
  image: '🌹'
}
```

## Update WhatsApp Number
Edit the WhatsApp number (9596287324) in `App.jsx` if needed.

## Support
Need help? Contact us on WhatsApp: +91 95962 87324

---
Made with ❤️ for AL HAYA ATTAR & PERFUMES
